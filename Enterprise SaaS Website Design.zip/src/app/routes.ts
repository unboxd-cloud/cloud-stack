import { createBrowserRouter } from "react-router";
import { MainLayout } from "./components/MainLayout";
import { LandingPage } from "./components/LandingPage";
import { ArchitecturePage } from "./components/ArchitecturePage";
import { PricingPage } from "./components/PricingPage";
import { DashboardPage } from "./components/DashboardPage";
import { LoginPage } from "./components/LoginPage";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/",
    Component: MainLayout,
    children: [
      { index: true, Component: LandingPage },
      { path: "architecture", Component: ArchitecturePage },
      { path: "pricing", Component: PricingPage },
      { path: "dashboard", Component: DashboardPage },
    ],
  },
]);
