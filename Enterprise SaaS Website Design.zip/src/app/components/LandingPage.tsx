import { Link } from "react-router";
import {
  Cloud,
  Server,
  Shield,
  Zap,
  Users,
  BarChart3,
  Lock,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";

export function LandingPage() {
  const features = [
    {
      icon: Shield,
      title: "Multi-tenant Isolation",
      description: "Complete security isolation between tenants with dedicated virtual networks and resource boundaries.",
    },
    {
      icon: Server,
      title: "Fully Managed Infrastructure",
      description: "We handle deployment, monitoring, updates, and maintenance. You focus on your business.",
    },
    {
      icon: Zap,
      title: "VM Provisioning in Seconds",
      description: "Deploy virtual machines instantly with our optimized CloudStack engine.",
    },
    {
      icon: Lock,
      title: "Network Isolation Per Customer",
      description: "Private VLANs, VPNs, and firewall rules for each tenant with zero cross-contamination.",
    },
    {
      icon: Users,
      title: "Resource Quotas & Limits",
      description: "Fine-grained control over CPU, RAM, storage, and network allocation per tenant.",
    },
    {
      icon: BarChart3,
      title: "24/7 Monitoring & SLA Support",
      description: "Enterprise SLA guarantees with proactive monitoring and incident response.",
    },
  ];

  const steps = [
    {
      number: "01",
      title: "We Deploy Your Private Cloud",
      description: "Our team provisions a dedicated CloudStack environment tailored to your infrastructure requirements.",
    },
    {
      number: "02",
      title: "You Get Tenant-Based Access Portal",
      description: "Secure multi-tenant dashboard for your customers with role-based access control.",
    },
    {
      number: "03",
      title: "We Operate & Manage Everything",
      description: "24/7 monitoring, updates, scaling, and support. You never touch the infrastructure layer.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-secondary">
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.02]"></div>
        <div className="container mx-auto px-6 py-24 md:py-32 relative">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm mb-6 border border-primary/20">
              <Cloud className="w-3 h-3" />
              <span>Enterprise Cloud Infrastructure</span>
            </div>

            <h1 className="text-4xl md:text-6xl tracking-tight mb-6">
              Your Private Cloud.
              <br />
              <span className="text-primary">Fully Managed.</span>
              <br />
              Enterprise Ready.
            </h1>

            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Multi-tenant private cloud infrastructure powered by Apache CloudStack.
              Built for enterprises and hosting providers who demand AWS-like capabilities
              with complete control and isolation.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/pricing"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
              >
                Request Demo
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/architecture"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground border border-border rounded-lg hover:bg-muted transition-colors"
              >
                Talk to Cloud Architect
              </Link>
            </div>

            <div className="mt-12 flex items-center justify-center gap-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-accent" />
                <span>99.99% Uptime SLA</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-accent" />
                <span>SOC 2 Compliant</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-accent" />
                <span>24/7 Support</span>
              </div>
            </div>
          </div>
        </div>

        {/* Abstract cloud visualization */}
        <div className="absolute -bottom-32 left-1/2 -translate-x-1/2 w-[800px] h-64 bg-primary/5 rounded-full blur-3xl"></div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl tracking-tight mb-4">
              Enterprise Features
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to run a production-grade private cloud platform
              with complete tenant isolation and management.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="p-6 rounded-xl border border-border bg-card hover:border-primary/50 transition-colors group"
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-secondary">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl tracking-tight mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From deployment to daily operations, we handle the complexity
              so you can focus on delivering value to your customers.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
              {/* Connection line */}
              <div className="hidden md:block absolute top-16 left-0 right-0 h-0.5 bg-border -z-10"></div>

              {steps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="bg-card border border-border rounded-xl p-6 h-full">
                    <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center mb-4 relative z-10">
                      <span className="text-lg">{step.number}</span>
                    </div>
                    <h3 className="text-lg mb-3">{step.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl tracking-tight mb-4">
            Ready to Deploy Your Private Cloud?
          </h2>
          <p className="text-primary-foreground/80 text-lg mb-8 max-w-2xl mx-auto">
            Join enterprises and hosting providers who trust our managed CloudStack platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/pricing"
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-background text-foreground rounded-lg hover:opacity-90 transition-opacity"
            >
              View Pricing
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/architecture"
              className="inline-flex items-center justify-center gap-2 px-6 py-3 border-2 border-primary-foreground/20 text-primary-foreground rounded-lg hover:bg-primary-foreground/10 transition-colors"
            >
              Explore Architecture
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
