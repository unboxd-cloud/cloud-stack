import { Check, ArrowRight } from "lucide-react";
import { Link } from "react-router";

export function PricingPage() {
  const plans = [
    {
      name: "Starter",
      description: "Perfect for small deployments and proof of concepts",
      price: "$2,499",
      period: "/month",
      features: [
        "Up to 50 VMs",
        "500 GB storage",
        "Basic SLA (99.5%)",
        "Email support",
        "5 tenant accounts",
        "Community templates",
        "Standard monitoring",
      ],
      cta: "Get Started",
      highlighted: false,
    },
    {
      name: "Business",
      description: "For growing businesses with managed scaling",
      price: "$7,999",
      period: "/month",
      features: [
        "Up to 500 VMs",
        "5 TB storage",
        "Enhanced SLA (99.9%)",
        "24/7 phone & email support",
        "Unlimited tenant accounts",
        "Custom templates & ISOs",
        "Advanced monitoring & alerts",
        "Dedicated account manager",
        "Automated backups",
      ],
      cta: "Request Demo",
      highlighted: true,
    },
    {
      name: "Enterprise",
      description: "Dedicated clusters with white-glove service",
      price: "Custom",
      period: "pricing",
      features: [
        "Unlimited VMs",
        "Unlimited storage",
        "Premium SLA (99.99%)",
        "24/7 priority support + Slack",
        "Custom multi-zone deployment",
        "Private templates & registry",
        "Custom integrations",
        "Dedicated cloud architect",
        "DR & geo-replication",
        "Compliance assistance (SOC 2, HIPAA)",
      ],
      cta: "Contact Sales",
      highlighted: false,
    },
  ];

  return (
    <div className="py-16">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="text-4xl md:text-5xl tracking-tight mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-lg text-muted-foreground">
            Choose the plan that fits your infrastructure needs.
            All plans include fully managed CloudStack operations.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto mb-16">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-xl p-8 flex flex-col ${
                plan.highlighted
                  ? "bg-primary text-primary-foreground border-2 border-primary shadow-xl scale-105"
                  : "bg-card border border-border"
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-accent text-accent-foreground rounded-full text-xs">
                  Most Popular
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-xl mb-2">{plan.name}</h3>
                <p
                  className={`text-sm ${
                    plan.highlighted ? "text-primary-foreground/80" : "text-muted-foreground"
                  }`}
                >
                  {plan.description}
                </p>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl">{plan.price}</span>
                  <span
                    className={`text-sm ${
                      plan.highlighted ? "text-primary-foreground/80" : "text-muted-foreground"
                    }`}
                  >
                    {plan.period}
                  </span>
                </div>
              </div>

              <ul className="space-y-3 mb-8 flex-grow">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check
                      className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                        plan.highlighted ? "text-primary-foreground" : "text-accent"
                      }`}
                    />
                    <span
                      className={`text-sm ${
                        plan.highlighted ? "text-primary-foreground/90" : "text-foreground"
                      }`}
                    >
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              <Link
                to="/login"
                className={`w-full py-3 rounded-lg transition-colors flex items-center justify-center gap-2 ${
                  plan.highlighted
                    ? "bg-background text-foreground hover:opacity-90"
                    : "bg-primary text-primary-foreground hover:opacity-90"
                }`}
              >
                {plan.cta}
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto mt-24">
          <h2 className="text-2xl mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">What's included in "fully managed"?</h3>
              <p className="text-sm text-muted-foreground">
                We handle all infrastructure operations including deployment, monitoring,
                patching, updates, backups, and 24/7 incident response. You get a working
                CloudStack environment without touching the underlying systems.
              </p>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">Can I scale between plans?</h3>
              <p className="text-sm text-muted-foreground">
                Yes. You can upgrade or downgrade at any time. We'll migrate your
                configuration and tenants seamlessly with zero downtime.
              </p>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">What hypervisor do you support?</h3>
              <p className="text-sm text-muted-foreground">
                We use KVM by default for optimal performance and cost. VMware ESXi
                and XenServer are available for Enterprise plans upon request.
              </p>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">Do you offer custom deployments?</h3>
              <p className="text-sm text-muted-foreground">
                Enterprise customers can request custom architectures including
                multi-zone, edge deployments, hybrid cloud integration, and
                specialized compliance configurations.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="max-w-4xl mx-auto mt-16 text-center bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-xl p-12">
          <h2 className="text-2xl md:text-3xl mb-4">
            Need a Custom Solution?
          </h2>
          <p className="text-muted-foreground mb-6">
            Talk to our cloud architects about custom deployments, dedicated regions,
            or specialized compliance requirements.
          </p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
          >
            Schedule Architecture Call
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
