import { useState } from "react";
import {
  Server,
  Plus,
  Power,
  PowerOff,
  RefreshCw,
  Trash2,
  Cpu,
  HardDrive,
  Network,
  Activity,
  ChevronDown,
  BarChart3,
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function DashboardPage() {
  const [selectedTenant, setSelectedTenant] = useState("Acme Corporation");

  const tenants = ["Acme Corporation", "TechStart Inc", "Global Hosting Ltd"];

  const vms = [
    {
      id: "vm-001",
      name: "web-server-01",
      status: "running",
      cpu: "4 vCPU",
      ram: "16 GB",
      storage: "100 GB SSD",
      ip: "10.0.1.45",
    },
    {
      id: "vm-002",
      name: "database-primary",
      status: "running",
      cpu: "8 vCPU",
      ram: "32 GB",
      storage: "500 GB SSD",
      ip: "10.0.1.46",
    },
    {
      id: "vm-003",
      name: "app-server-02",
      status: "stopped",
      cpu: "2 vCPU",
      ram: "8 GB",
      storage: "50 GB SSD",
      ip: "10.0.1.47",
    },
    {
      id: "vm-004",
      name: "cache-redis",
      status: "running",
      cpu: "2 vCPU",
      ram: "16 GB",
      storage: "100 GB SSD",
      ip: "10.0.1.48",
    },
  ];

  const cpuData = [
    { time: "00:00", value: 45 },
    { time: "04:00", value: 32 },
    { time: "08:00", value: 68 },
    { time: "12:00", value: 72 },
    { time: "16:00", value: 85 },
    { time: "20:00", value: 58 },
  ];

  const ramData = [
    { time: "00:00", value: 62 },
    { time: "04:00", value: 58 },
    { time: "08:00", value: 71 },
    { time: "12:00", value: 78 },
    { time: "16:00", value: 82 },
    { time: "20:00", value: 69 },
  ];

  const storageData = [
    { time: "00:00", value: 48 },
    { time: "04:00", value: 49 },
    { time: "08:00", value: 52 },
    { time: "12:00", value: 54 },
    { time: "16:00", value: 56 },
    { time: "20:00", value: 58 },
  ];

  return (
    <div className="min-h-screen bg-secondary">
      {/* Dashboard Header */}
      <div className="bg-background border-b border-border">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl mb-1">Cloud Dashboard</h1>
              <p className="text-sm text-muted-foreground">
                Manage your virtual infrastructure
              </p>
            </div>

            <div className="relative">
              <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg bg-background hover:bg-muted transition-colors">
                <Server className="w-4 h-4" />
                <span className="text-sm">{selectedTenant}</span>
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Total VMs</span>
                <Server className="w-4 h-4 text-primary" />
              </div>
              <div className="text-2xl">12</div>
              <div className="text-xs text-accent mt-1">8 running</div>
            </div>

            <div className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">CPU Usage</span>
                <Cpu className="w-4 h-4 text-primary" />
              </div>
              <div className="text-2xl">68%</div>
              <div className="text-xs text-muted-foreground mt-1">48 / 96 vCPU</div>
            </div>

            <div className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Memory</span>
              <Activity className="w-4 h-4 text-primary" />
              </div>
              <div className="text-2xl">72%</div>
              <div className="text-xs text-muted-foreground mt-1">230 / 512 GB</div>
            </div>

            <div className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Storage</span>
                <HardDrive className="w-4 h-4 text-primary" />
              </div>
              <div className="text-2xl">2.8 TB</div>
              <div className="text-xs text-muted-foreground mt-1">of 5 TB allocated</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* CPU Chart */}
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm">CPU Usage (24h)</h3>
              <Cpu className="w-4 h-4 text-primary" />
            </div>
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={cpuData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                <YAxis tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.5rem",
                  }}
                />
                <Line type="monotone" dataKey="value" stroke="var(--primary)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* RAM Chart */}
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm">Memory Usage (24h)</h3>
              <Activity className="w-4 h-4 text-primary" />
            </div>
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={ramData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                <YAxis tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.5rem",
                  }}
                />
                <Line type="monotone" dataKey="value" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Storage Chart */}
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm">Storage Growth (24h)</h3>
              <HardDrive className="w-4 h-4 text-primary" />
            </div>
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={storageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                <YAxis tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.5rem",
                  }}
                />
                <Line type="monotone" dataKey="value" stroke="var(--chart-3)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* VM List */}
        <div className="bg-card border border-border rounded-lg">
          <div className="p-6 border-b border-border flex items-center justify-between">
            <h2 className="text-lg">Virtual Machines</h2>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity text-sm">
              <Plus className="w-4 h-4" />
              Create VM
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className="text-left p-4 text-sm">Name</th>
                  <th className="text-left p-4 text-sm">Status</th>
                  <th className="text-left p-4 text-sm">Resources</th>
                  <th className="text-left p-4 text-sm">IP Address</th>
                  <th className="text-left p-4 text-sm">Actions</th>
                </tr>
              </thead>
              <tbody>
                {vms.map((vm) => (
                  <tr key={vm.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <Server className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <div className="text-sm">{vm.name}</div>
                          <div className="text-xs text-muted-foreground">{vm.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs ${
                          vm.status === "running"
                            ? "bg-accent/10 text-accent"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            vm.status === "running" ? "bg-accent" : "bg-muted-foreground"
                          }`}
                        ></span>
                        {vm.status}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="text-xs text-muted-foreground space-y-0.5">
                        <div>{vm.cpu}</div>
                        <div>{vm.ram}</div>
                        <div>{vm.storage}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-1.5 text-sm">
                        <Network className="w-3 h-3 text-muted-foreground" />
                        {vm.ip}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <button
                          className="p-1.5 hover:bg-muted rounded transition-colors"
                          title={vm.status === "running" ? "Stop" : "Start"}
                        >
                          {vm.status === "running" ? (
                            <PowerOff className="w-4 h-4 text-muted-foreground" />
                          ) : (
                            <Power className="w-4 h-4 text-accent" />
                          )}
                        </button>
                        <button
                          className="p-1.5 hover:bg-muted rounded transition-colors"
                          title="Reboot"
                        >
                          <RefreshCw className="w-4 h-4 text-muted-foreground" />
                        </button>
                        <button
                          className="p-1.5 hover:bg-destructive/10 rounded transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Network & Firewall Section */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg mb-4">Network Configuration</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Isolated Network</span>
                <span>10.0.1.0/24</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Gateway</span>
                <span>10.0.1.1</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">DNS Servers</span>
                <span>8.8.8.8, 8.8.4.4</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-muted-foreground">VLAN ID</span>
                <span>VLAN-2845</span>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg mb-4">Resource Quotas</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">vCPU</span>
                  <span>48 / 96</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: "50%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Memory</span>
                  <span>230 / 512 GB</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-chart-2" style={{ width: "45%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Storage</span>
                  <span>2.8 / 5 TB</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-chart-3" style={{ width: "56%" }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
