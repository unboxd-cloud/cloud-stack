import {
  Server,
  Network,
  Database,
  HardDrive,
  Users,
  Shield,
  Activity,
  Layers,
} from "lucide-react";

export function ArchitecturePage() {
  return (
    <div className="py-16">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="text-4xl md:text-5xl tracking-tight mb-4">
            Platform Architecture
          </h1>
          <p className="text-lg text-muted-foreground">
            Enterprise-grade multi-tenant infrastructure powered by Apache CloudStack
            with complete isolation and scalability.
          </p>
        </div>

        {/* Architecture Diagram */}
        <div className="max-w-6xl mx-auto mb-16">
          <div className="bg-card border border-border rounded-xl p-8 md:p-12">
            <h3 className="text-xl mb-8 text-center">CloudStack Multi-Tenant Architecture</h3>

            {/* Tenant Layer */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-primary" />
                <span className="text-sm">Multi-Tenant Layer</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {["Customer A", "Customer B", "Customer C"].map((tenant, i) => (
                  <div
                    key={i}
                    className="border-2 border-primary/30 rounded-lg p-4 bg-primary/5"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="w-4 h-4 text-primary" />
                      <span className="text-sm">{tenant}</span>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Isolated Networks</div>
                      <div>• Resource Quotas</div>
                      <div>• Dedicated VMs</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* CloudStack Control Plane */}
            <div className="relative mb-8">
              <div className="absolute left-1/2 -translate-x-1/2 -top-4 w-px h-8 bg-border"></div>
              <div className="border-2 border-primary rounded-lg p-6 bg-primary/10">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Layers className="w-5 h-5 text-primary" />
                  <span>CloudStack Control Plane</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                  <div className="text-center">
                    <Activity className="w-4 h-4 mx-auto mb-1 text-primary" />
                    <div className="text-xs">Management Server</div>
                  </div>
                  <div className="text-center">
                    <Network className="w-4 h-4 mx-auto mb-1 text-primary" />
                    <div className="text-xs">Virtual Router</div>
                  </div>
                  <div className="text-center">
                    <Server className="w-4 h-4 mx-auto mb-1 text-primary" />
                    <div className="text-xs">Console Proxy</div>
                  </div>
                  <div className="text-center">
                    <HardDrive className="w-4 h-4 mx-auto mb-1 text-primary" />
                    <div className="text-xs">Storage Controller</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Physical Infrastructure */}
            <div className="relative">
              <div className="absolute left-1/2 -translate-x-1/2 -top-4 w-px h-8 bg-border"></div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="border border-border rounded-lg p-4 bg-muted/30">
                  <div className="text-sm mb-2">Zone</div>
                  <div className="text-xs text-muted-foreground">
                    Data Center Region
                  </div>
                </div>
                <div className="border border-border rounded-lg p-4 bg-muted/30">
                  <div className="text-sm mb-2">Pod</div>
                  <div className="text-xs text-muted-foreground">
                    Rack/Network Segment
                  </div>
                </div>
                <div className="border border-border rounded-lg p-4 bg-muted/30">
                  <div className="text-sm mb-2">Cluster</div>
                  <div className="text-xs text-muted-foreground">
                    Hypervisor Group
                  </div>
                </div>
                <div className="border border-border rounded-lg p-4 bg-muted/30">
                  <div className="text-sm mb-2">Hosts</div>
                  <div className="text-xs text-muted-foreground">
                    Physical Servers
                  </div>
                </div>
              </div>
            </div>

            {/* Storage Layer */}
            <div className="mt-8 border border-border rounded-lg p-6 bg-secondary">
              <div className="flex items-center gap-2 mb-3">
                <Database className="w-5 h-5 text-primary" />
                <span className="text-sm">Storage Layer</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-muted-foreground">
                <div>Primary Storage (VM Disks)</div>
                <div>Secondary Storage (Templates/ISOs)</div>
                <div>Object Storage (Snapshots/Backups)</div>
              </div>
            </div>
          </div>
        </div>

        {/* Key Components */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl mb-8 text-center">Key Components</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">Management Server</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Centralized control plane for orchestrating all cloud operations,
                API endpoints, and tenant management.
              </p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• REST API for automation</li>
                <li>• Multi-tenant authentication</li>
                <li>• Resource scheduling & allocation</li>
              </ul>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">Virtual Router</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Per-tenant virtual networking with DHCP, DNS, NAT, VPN, and firewall
                capabilities.
              </p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Isolated network per tenant</li>
                <li>• Advanced firewall rules</li>
                <li>• Site-to-site VPN support</li>
              </ul>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">Hypervisor Layer</h3>
              <p className="text-sm text-muted-foreground mb-3">
                KVM-based virtualization with live migration, snapshots, and
                high availability.
              </p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Live VM migration</li>
                <li>• Automatic failover</li>
                <li>• Resource overcommit control</li>
              </ul>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-lg mb-2">Storage System</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Distributed storage with SAN/NAS integration, snapshots, and
                automated backups.
              </p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Volume snapshots & cloning</li>
                <li>• Automated backup scheduling</li>
                <li>• Multi-tier storage policies</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Security & Compliance */}
        <div className="max-w-4xl mx-auto mt-16">
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-xl p-8">
            <h2 className="text-2xl mb-4">Security & Compliance</h2>
            <p className="text-muted-foreground mb-6">
              Enterprise-grade security controls with complete tenant isolation
              and compliance certifications.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-start gap-2">
                <Shield className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <div className="mb-1">Network Isolation</div>
                  <div className="text-xs text-muted-foreground">
                    VLAN/VXLAN segmentation per tenant
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Shield className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <div className="mb-1">SOC 2 Type II</div>
                  <div className="text-xs text-muted-foreground">
                    Annual compliance audits
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Shield className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <div className="mb-1">Encryption</div>
                  <div className="text-xs text-muted-foreground">
                    Data at rest & in transit
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
